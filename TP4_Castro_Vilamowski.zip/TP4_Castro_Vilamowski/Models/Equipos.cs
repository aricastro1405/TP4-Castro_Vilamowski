using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace TP4_Castro_Vilamowski.Models{
    public static class Equipos{
        static public List<string> ListaEquipos {get; private set;}=new List<string>(){"Boca","River","Independiente","Racing","Argentinos Jrs.", "Vélez", "San Lorenzo", "AllBoys", "Huracán", "Estudiantes"};
        static public List<string> ListaMedias {get; private set;}=new List<string>(){"medias_boca.png","medias_river.png","medias_independiente.avif","medias_racing.png","medias_argjrs.png","medias_velez.png","medias_sanlo.png","medias_allboys.png","medias_huracan.png","medias_estudiantes.png"};
        static public List<string> ListaPantalones {get; private set;}=new List<string>(){"pantalones_boca.png","pantalones_river.png","pantalones_independiente.png","pantalones_racing.png","pantalones_argjrs.png","pantalones_velez.png","pantalones_sanlo.avif","pantalones_allboys.png","pantalones_huracan.png","pantalones_estudiantes.png"};
        static public List<string> ListaRemeras {get; private set;}=new List<string>(){"remera_boca.png","remera_river.png","remera_independiente.jpg","remera_racing.png","remera_argjrs.png","remera_velez.png","remera_sanlo.avif","remera_allboys.png","remera_huracan.png","remera_estudiantes.png"};
        static public Dictionary<string, Indumentaria> EquiposIndumentaria {get; private set;}
        bool IngresarIndumentaria(string EquipoSeleccionado, Indumentaria item){
            bool sePuede=false;
            foreach(string e in EquiposIndumentaria.Keys){
                if(e!=EquipoSeleccionado){
                    EquiposIndumentaria.Add(EquipoSeleccionado,item);
                    sePuede=true;
                    return sePuede;
                }
            }
        }
    }
}