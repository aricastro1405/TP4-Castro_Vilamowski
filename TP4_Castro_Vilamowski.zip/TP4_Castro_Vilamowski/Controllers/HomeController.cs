﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using TP4_Castro_Vilamowski.Models;

namespace TP4_Castro_Vilamowski.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        ViewBag.IndumentariasEquipos=EquiposIndumentaria();
        return View("Index");
    }
    public IActionResult SelectIndumentaria(){
        ViewBag.MediasLista=ListaMedias();
        ViewBag.PantalonesLista=ListaPantalones();
        ViewBag.RemerasLista=ListaRemeras();
        if(ViewBag.MediasLista>10||ViewBag.MediasLista<0){
            ViewBag.MensajeError="No existe esa opción!";
            return View (MensajeError);
        }
        else {
            IActionResult Index();
        }
        return View("SelectIndumentaria");
    }
    public IActionResult GuardarIndumentaria (int Equipo, int Media, int Pantalon, int Remera){
        Indumentaria item=new Indumentaria();
        string media=" ",pantalon=" ",remera=" ";
        switch(Remera){
            case 1:
            remera="remera_boca.png";
            break;
            case 2:
            remera="remera_river.png";
            break;
            case 3:
            remera="remera_independiente.jpg";
            break;
            case 4:
            remera="remera_racing.png";
            break;
            case 5:
            remera="remera_argjrs.png";
            break;
            case 6:
            remera="remera_velez.png";
            break;
            case 7:
            remera="remera_sanlo.avif";
            break;
            case 8:
            remera="remera_allboys.png";
            break;
            case 9:
            remera="remera_huracan.png";
            break;
            case 10:
            remera="remera_estudiantes.png";
            break;
        }
        switch(Pantalon){
            case 1:
            pantalon="pantalones_boca.png";
            break;
            case 2:
            pantalon="pantalones_river.png";
            break;
            case 3:
            pantalon="pantalones_independiente.png";
            break;
            case 4:
            pantalon="pantalones_racing.png";
            break;
            case 5:
            pantalon="pantalones_argjrs.png";
            break;
            case 6:
            pantalon="pantalones_velez.png";
            break;
            case 7:
            pantalon="pantalones_sanlo.avif";
            break;
            case 8:
            pantalon="pantalones_allboys.png";
            break;
            case 9:
            pantalon="pantalones_huracan.png";
            break;
            case 10:
            pantalon="pantalones_estudiantes.png";
            break;
        }
        switch(Media){
            case 1:
            media="medias_boca.png";
            break;
            case 2:
            media="medias_river.png";
            break;
            case 3:
            media="medias_independiente.avif";
            break;
            case 4:
            media="medias_racing.png";
            break;
            case 5:
            media="medias_argjrs.png";
            break;
            case 6:
            media="medias_velez.png";
            break;
            case 7:
            media="medias_sanlo.png";
            break;
            case 8:
            media="medias_allboys.png";
            break;
            case 9:
            media="medias_huracan.png";
            break;
            case 10:
            media="medias_estudiantes.png";
            break;
        }
        string EquipoSeleccionado;
        item.Medias=media;
        item.Pantalon=Pantalon;
        item.Camiseta=Remera;
        switch (Equipo){
            case 1:
            EquipoSeleccionado="Boca";
            break;
            case 2:
            EquipoSeleccionado="River";
            break;
            case 3:
            EquipoSeleccionado="Independiente";
            break;
            case 4:
            EquipoSeleccionado="Racing";
            break;
            case 5:
            EquipoSeleccionado="Argentinos Jrs.";
            break;
            case 6:
            EquipoSeleccionado="Vélez";
            break;
            case 7:
            EquipoSeleccionado="San Lorenzo";
            break;
            case 8:
            EquipoSeleccionado="All Boys";
            break;
            case 9:
            EquipoSeleccionado="Huracán";
            break;
            case 10:
            EquipoSeleccionado="Estudiantes";
            break;
        }
        Equipos.IngresarIndumentaria(EquipoSeleccionado,item);
        return View();
    }
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
